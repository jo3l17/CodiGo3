﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace Cajero
{
    class conexionDB
    {
        static SqlConnection con;
        static SqlCommand cmd;
        public conexionDB()
        {
            con = new SqlConnection("Data Source=DESKTOP-GGAU3TL\\SQLEXPRESS;" + "Initial Catalog = banco; Integrated Security = True");

        }
        public SqlConnection GetConnection()
        {
            return con;
        }
        public void AbrirConexion()
        {
            try
            {
                con.Open();
                Console.WriteLine("se conecto correctamente");
            }
            catch (Exception)
            {
                Console.WriteLine("no se pudo conectar");
            }

        }
        public void CerrarConexion()
        {
            try
            {
                con.Close();
                Console.WriteLine("Se cerro la conexion");
            }
            catch (Exception)
            {
                Console.WriteLine("no se pudo cerrar");
                throw;
            }
        }
    }
}
