﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Cajero;
using System.Data.SqlClient;
using Cajero.controlador;
using Cajero.entidades;

namespace Cajero
{
    
    public partial class verDatos : Form
    {
        conexionDB con = new conexionDB();
        SqlCommand cmd;
        ControladorUsuario cu = new ControladorUsuario();
        private string nroCuenta;

        public string cuentaSeleccionada
        {
            get { return nroCuenta; }
            set { nroCuenta = value; }
        }

        public verDatos()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void verDatos_Load(object sender, EventArgs e)
        {
            cuentas cuentaLoad = new cuentas();
            cuentaLoad = cu.getInformacionDeCuenta(nroCuenta);
            NroCuenta.Text = cuentaLoad.NroCuenta;
            Monto.Text = cuentaLoad.monto;
            Moneda.Text = cuentaLoad.moneda;

        }
    }
}
