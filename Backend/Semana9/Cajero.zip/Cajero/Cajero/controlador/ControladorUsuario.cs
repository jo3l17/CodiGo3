﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using Cajero.entidades;

namespace Cajero.controlador
{
    class ControladorUsuario
    {
        conexionDB con = new conexionDB();
        SqlCommand cmd;

        public string ingresar(cliente client)
        {
            con.AbrirConexion();
            cmd = new SqlCommand($"select count (*) from cajero.cliente where DNI = '{client.DNI}' and clave = '{client.clave}'",con.GetConnection());
            int resultado = Convert.ToInt32(cmd.ExecuteScalar());
            if (resultado==1)
            {
                cmd = new SqlCommand($"select Nombre from cajero.cliente where DNI = '{client.DNI}' and clave = '{client.clave}'", con.GetConnection());
                string Nombre = cmd.ExecuteScalar().ToString();
                con.CerrarConexion();
                return Nombre;
            }
            else
            {
                return "incorrecto";
            }
        }
        public List<string> getCuentas(cliente client)
        {

            con.AbrirConexion();
            cmd = new SqlCommand($"select * from cajero.cuentas where clienteDNI = '{client.DNI}'", con.GetConnection());
            int resultado = Convert.ToInt32(cmd.ExecuteScalar());
            List<string> list = new List<string>();
            
            SqlDataReader sqlReader = cmd.ExecuteReader();
            while (sqlReader.Read())
            {
                list.Add(sqlReader["NroCuenta"].ToString());
            }
            sqlReader.Close();
            con.CerrarConexion();

            return list;
        }
        public cuentas getInformacionDeCuenta(string cuenta)
        {
            con.AbrirConexion();
            cmd = new SqlCommand($"select * from cajero.cuentas where NroCuenta = '{cuenta}'", con.GetConnection());
            cuentas cuentaInfo = new cuentas();
            SqlDataReader sqlReader = cmd.ExecuteReader();
            sqlReader.Read();
            cuentaInfo.NroCuenta = cuenta;
            cuentaInfo.monto = sqlReader["monto"].ToString();
            cuentaInfo.moneda = sqlReader["moneda"].ToString();
            sqlReader.Close();
            con.CerrarConexion();
            return cuentaInfo;
        }
        public decimal depositar(string cuenta,int valor)
        {
            decimal valordecimal = decimal.Parse(valor.ToString());
            con.AbrirConexion();
            cmd = new SqlCommand($"select monto from cajero.cuentas where NroCuenta = '{cuenta}'", con.GetConnection());
            decimal monto = decimal.Parse(cmd.ExecuteScalar().ToString());
            decimal MontoCambiado = monto + valordecimal;
            cmd = new SqlCommand($"update cajero.cuentas set monto='{MontoCambiado}' where NroCuenta = '{cuenta}'", con.GetConnection());
            if (cmd.ExecuteNonQuery() > 0)
                Console.WriteLine($"se deposito {valordecimal} su nuevo saldo es{MontoCambiado}");
            con.CerrarConexion();
            return MontoCambiado;
        }
        public decimal retirar(string cuenta, int valor)
        {
            decimal valordecimal = decimal.Parse(valor.ToString());
            con.AbrirConexion();
            cmd = new SqlCommand($"select monto from cajero.cuentas where NroCuenta = '{cuenta}'", con.GetConnection());
            decimal monto = decimal.Parse(cmd.ExecuteScalar().ToString());
            decimal MontoCambiado = monto - valordecimal;
            cmd = new SqlCommand($"update cajero.cuentas set monto='{MontoCambiado}' where NroCuenta = '{cuenta}'", con.GetConnection());
            if (cmd.ExecuteNonQuery() > 0)
                Console.WriteLine($"se retiro {valordecimal} su nuevo saldo es {MontoCambiado}");
            con.CerrarConexion();
            return MontoCambiado;
        }
        
    }
}
