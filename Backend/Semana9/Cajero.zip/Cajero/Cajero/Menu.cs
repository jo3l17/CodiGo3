﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Cajero;
using System.Data.SqlClient;
using Cajero.controlador;
using Cajero.entidades;

namespace Cajero
{
    public partial class Menu : Form
    {
        conexionDB con = new conexionDB();
        SqlCommand cmd;
        ControladorUsuario cu = new ControladorUsuario();
        int i = 0;
        string cuentaSeleccionada = "";
        public Menu()
        {
            InitializeComponent();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            int index = comboBox1.SelectedIndex;
            cuentaSeleccionada = comboBox1.Items[index].ToString();

        }
        int index = 1;
        private void button5_Click(object sender, EventArgs e)
        {
            this.Close();
            Application.Exit();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (cuentaSeleccionada != "")
            {
                retirar retirar = new retirar();
                Console.WriteLine(cuentaSeleccionada);
                retirar.cuentaSeleccionada = cuentaSeleccionada;
                retirar.ShowDialog();
            }
            else
            {
                MessageBox.Show("no ha seleccionado cuenta");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (cuentaSeleccionada != "")
            {
                depositar depositar = new depositar();
                Console.WriteLine(cuentaSeleccionada);
                depositar.cuentaSeleccionada = cuentaSeleccionada;
                depositar.ShowDialog();
            }
            else
            {
                MessageBox.Show("no ha seleccionado cuenta");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (cuentaSeleccionada != "")
            {
                transferir transferir = new transferir();
                Console.WriteLine(cuentaSeleccionada);
                transferir.cuentaSeleccionada = cuentaSeleccionada;
                transferir.ShowDialog();
            }
            else
            {
                MessageBox.Show("no ha seleccionado cuenta");
            }
        }

        
        private void timer1_Tick(object sender, EventArgs e)
        {
            i++;
            label1.Text = $"{i}";
        }

        private void label1_Click(object sender, EventArgs e)
        {
            
        }

        private cliente myclientlogcuenta;
        private void Menu_Load(object sender, EventArgs e)
        {
            var a = cu.getCuentas(myclientlogcuenta);
            comboBox1.Items.AddRange(a.ToArray());
        }

        private void button4_Click(object sender, EventArgs e)
        {
            
            if (cuentaSeleccionada != "")
            {
                verDatos verDatos = new verDatos();
                Console.WriteLine(cuentaSeleccionada);
                verDatos.cuentaSeleccionada = cuentaSeleccionada;
                verDatos.ShowDialog();
            }
            else
            {
                MessageBox.Show("no ha seleccionado cuenta");
            }
            
        }
        
        public cliente clientlogcuenta
        {
            get { return myclientlogcuenta; }
            set { myclientlogcuenta = value; }
        }
    }
}
