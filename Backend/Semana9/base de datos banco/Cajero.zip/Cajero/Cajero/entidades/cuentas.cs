﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cajero.entidades
{
    class cuentas
    {
        public string NroCuenta { get; set; }
        public string monto { get; set; }
        public string moneda { get; set; }
    }
}
