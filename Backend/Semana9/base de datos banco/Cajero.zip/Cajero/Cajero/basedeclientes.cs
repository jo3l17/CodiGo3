﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cajero
{
    public partial class basedeclientes : Form
    {
        public basedeclientes()
        {
            InitializeComponent();
        }

        private void basedeclientes_Load(object sender, EventArgs e)
        {
            // TODO: esta línea de código carga datos en la tabla 'bancoDataSet.cuentas' Puede moverla o quitarla según sea necesario.
            this.cuentasTableAdapter.Fill(this.bancoDataSet.cuentas);
            // TODO: esta línea de código carga datos en la tabla 'bancoDataSet.cliente' Puede moverla o quitarla según sea necesario.
            this.clienteTableAdapter.Fill(this.bancoDataSet.cliente);

        }
    }
}
