﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Cajero.entidades;
using Cajero.controlador;

namespace Cajero
{
    public partial class Form1 : Form
    {
        ControladorUsuario cliente;
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            cliente clientlog = new cliente()
            {
                DNI = textboxDNI.Text ,
                clave = textboxPass.Text
            };
            cliente = new ControladorUsuario();
            var intento = cliente.ingresar(clientlog);
            if (intento!="incorrecto")
            {
                MessageBox.Show($"bienvenido {intento}");
                Menu menu = new Menu();
                menu.clientlogcuenta = clientlog;
                menu.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("DNI y/o clave incorrectos");
            }

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
