﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using Cajero.entidades;

namespace Cajero.controlador
{
    class ControladorUsuario
    {
        conexionDB con = new conexionDB();
        SqlCommand cmd;

        public string ingresar(cliente client)
        {
            con.AbrirConexion();
            cmd = new SqlCommand($"select count (*) from cajero.cliente where DNI = '{client.DNI}' and clave = '{client.clave}'",con.GetConnection());
            int resultado = Convert.ToInt32(cmd.ExecuteScalar());
            if (resultado==1)
            {
                cmd = new SqlCommand($"select Nombre from cajero.cliente where DNI = '{client.DNI}' and clave = '{client.clave}'", con.GetConnection());
                string Nombre = cmd.ExecuteScalar().ToString();
                con.CerrarConexion();
                return Nombre;
            }
            else
            {
                return "incorrecto";
            }
        }
        public string [] getCuentas(cliente client)
        {

            con.AbrirConexion();
            cmd = new SqlCommand($"select * from cajero.cuentas where clienteDNI = '{client.DNI}'", con.GetConnection());
            SqlDataReader sqlReader = cmd.ExecuteReader();
            int resultado = Convert.ToInt32(cmd.ExecuteScalar());
            List<string> list = new List<string>();
            while (sqlReader.Read())
            {
                list.Add(sqlReader["NroCuenta"].ToString());
            }
            sqlReader.Close();
            con.CerrarConexion();
            return list;
        }
    }
}
