﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cajero.entidades
{
    public class cliente
    {
        public string DNI { get; set; }
        public string clave { get; set; }
    }
}
