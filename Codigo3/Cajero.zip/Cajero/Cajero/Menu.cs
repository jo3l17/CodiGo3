﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Cajero;
using System.Data.SqlClient;
using Cajero.controlador;
using Cajero.entidades;

namespace Cajero
{
    public partial class Menu : Form
    {
        conexionDB con = new conexionDB();
        SqlCommand cmd;
        ControladorUsuario cu = new ControladorUsuario();
        int i = 0;
        public Menu()
        {
            InitializeComponent();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Close();
            Application.Exit();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            retirar retirar = new retirar();
            retirar.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            depositar depositar = new depositar();
            depositar.ShowDialog();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            transferir transferir = new transferir();
            transferir.ShowDialog();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            i++;
            label1.Text = $"{i}";
        }

        private void label1_Click(object sender, EventArgs e)
        {
            
        }

        private void Menu_Load(object sender, EventArgs e)
        {

            /*SqlCommand sqlCmd = new SqlCommand($"SELECT * FROM cajero.cuentas where clienteDNI ={client.DNI}", con.GetConnection());
            con.AbrirConexion();
            SqlDataReader sqlReader = sqlCmd.ExecuteReader();
            while (sqlReader.Read())
            {
                comboBox1.Items.Add(sqlReader["NroCuenta"].ToString());
            }
            con.CerrarConexion();*/

            cliente asdf = new cliente();
            comboBox1.Items.AddRange(cu.getCuentas(asdf));
        }

        private void button4_Click(object sender, EventArgs e)
        {
            verDatos verDatos = new verDatos();
            verDatos.ShowDialog();
        }
        private int myVar;

        public cliente clientlog
        {
            get { return clientlog; }
            set { clientlog = value; }
        }

    }
}
